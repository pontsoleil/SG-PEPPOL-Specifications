XSLT for visual presentation of invoice
